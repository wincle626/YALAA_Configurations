#!/bin/sh
./configure --with-boost=$HOME/libs/boost --with-cxsc=$HOME/libs/cxsc --prefix=$HOME/libs/yalaa/  --disable-debug


