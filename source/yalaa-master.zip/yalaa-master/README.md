yalaa
=====

Yet Another Library for Affine Arithmetic

See http://www.scg.inf.uni-due.de/fileadmin/Projekte/YalAA/ for details.
