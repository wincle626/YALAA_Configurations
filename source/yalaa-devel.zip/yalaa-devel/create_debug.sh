#!/bin/sh
./configure --with-boost=$HOME/libs/boost --with-cxsc=$HOME/libs/cxsc --disable-shared --enable-debug


